<?php $__env->startSection('title', 'Add a New CheckIn'); ?>

<?php $__env->startSection('content'); ?>
    <section>
        <div class="section-body">
            <form class="form form-validate floating-label" action="<?php echo e(route('checkin.store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo $__env->make('checkin.form',['header' => 'Add new CheckIn'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </form>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function(){

            $('#room_type').on('change', function(e){
                e.preventDefault();
                var room_id = $(this).val();
                $.ajaxSetup({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        }
                    });
                $.ajax({
                    type: "POST",
                    url: "<?php echo e(route('checkin.get_room_price')); ?>",
                    data:{
                        room_id:room_id
                    },
                    dataType: "json",
                    success: function(response){
                        $('.roomprice').val(response.message.price)
                    }
                })
            });
        });


    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\customermanagement\resources\views/checkin/create.blade.php ENDPATH**/ ?>