<?php echo $__env->make('layouts.admin.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <body data-topbar="dark">

        <!-- Begin page -->
        <div id="layout-wrapper">
                    <div class="container-fluid">
                        <?php echo $__env->yieldContent('content'); ?>
                    </div>

        </div>
<?php /**PATH C:\xampp\htdocs\customermanagement\resources\views/layouts/app.blade.php ENDPATH**/ ?>