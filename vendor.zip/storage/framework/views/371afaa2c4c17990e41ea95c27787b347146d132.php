<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-6">
                2018 - <script>document.write(new Date().getFullYear())</script> © Surkheti Gurbhakot Geust House
            </div>
        </div>
    </div>
</footer>




<?php /**PATH /home/demoaccessworld/public_html/projects/customermanagement/resources/views/layouts/admin/footer.blade.php ENDPATH**/ ?>