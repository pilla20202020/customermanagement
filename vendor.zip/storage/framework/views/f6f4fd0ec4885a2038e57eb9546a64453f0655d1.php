<?php $__env->startSection('title', 'View Customers'); ?>

<?php $__env->startSection('page-specific-styles'); ?>
    <link href="<?php echo e(asset('css/dropify.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('resources/css/bootstrap-toggle.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


    <div class="row">
        <div class="col-md-12 col-lg-10 mx-auto">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Customer Detail of <span class="text-danger">
                            (<?php echo e($customer->first_name); ?> <?php echo e($customer->middle_name); ?>

                            <?php echo e($customer->last_name); ?>)</span></h5>
                    <div class="row mt-5">
                        <div class="col-sm-4 form-group">
                            <label for="name" class="pt-0">Name: </label>
                            <span> <?php echo e($customer->first_name); ?> <?php echo e($customer->middle_name); ?>

                                <?php echo e($customer->last_name); ?></span>
                        </div>
                        <div class="col-sm-4 form-group">
                            <label for="name" class="pt-0">Email: </label>
                            <span> <?php echo e($customer->email); ?></span>
                        </div>
                        <div class="col-sm-4 form-group">
                            <label for="name" class="pt-0">Contact Number: </label>
                            <span> <?php echo e($customer->mobile_no); ?></span>
                        </div>
                        <div class="col-sm-4 form-group">
                            <label for="name" class="pt-0">Gender: </label>
                            <span> <?php echo e(ucfirst($customer->gender)); ?></span>
                        </div>
                        <div class="col-sm-4 form-group">
                            <label for="name" class="pt-0">Marital Status: </label>
                            <span> <?php echo e(ucfirst($customer->marital_status)); ?></span>
                        </div>

                        <div class="col-sm-4 form-group">
                            <label for="name" class="pt-0">Date Of Birth: </label>
                            <span> <?php echo e(ucfirst($customer->dob)); ?></span>
                        </div>

                        <div class="col-sm-4 form-group">
                            <label for="name" class="pt-0">Father Name: </label>
                            <span> <?php echo e(ucfirst($customer->father_name)); ?></span>
                        </div>

                        <div class="col-sm-4 form-group">
                            <label for="name" class="pt-0">Mother Name: </label>
                            <span> <?php echo e(ucfirst($customer->mother_name)); ?></span>
                        </div>

                        <?php if($customer->spouse_name): ?>
                            <div class="col-sm-4 form-group">
                                <label for="name" class="pt-0">Spouse Name: </label>
                                <span> <?php echo e(ucfirst($customer->spouse_name)); ?></span>
                            </div>
                        <?php endif; ?>

                        <div class="col-sm-4 form-group">
                            <label for="name" class="pt-0">Nationality: </label>
                            <span> <?php echo e(ucfirst($customer->nationality)); ?></span>
                        </div>

                        <div class="col-sm-4 form-group">
                            <label for="name" class="pt-0">CitizenShip No: </label>
                            <span> <?php echo e(ucfirst($customer->citizenship)); ?></span>
                        </div>

                        <div class="col-sm-4 form-group">
                            <label for="name" class="pt-0">CitizenShip Issue Date: </label>
                            <span> <?php echo e(ucfirst($customer->citizenship_issue_date)); ?></span>
                        </div>

                        <div class="col-sm-4 form-group">
                            <label for="name" class="pt-0">Province: </label>
                            <span> <?php echo e(ucfirst($customer->customer_province->province_name)); ?></span>
                        </div>

                        <div class="col-sm-4 form-group">
                            <label for="name" class="pt-0">District: </label>
                            <span> <?php echo e(ucfirst($customer->customer_district->district_name)); ?></span>
                        </div>

                        <div class="col-sm-4 form-group">
                            <label for="name" class="pt-0">Municipality: </label>
                            <span> <?php echo e(ucfirst($customer->customer_municipality->name)); ?></span>
                        </div>

                        <div class="col-sm-4 form-group">
                            <label for="name" class="pt-0">Ward No.: </label>
                            <span> <?php echo e(ucfirst($customer->ward_no)); ?></span>
                        </div>

                        <?php if(isset($customer) && !empty($customer->image)): ?>
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="customer" class="col-form-label pt-0">Image: </label>
                                        <img src="<?php echo e(asset($customer->image_path)); ?>" alt="" height="100px">
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>


                        <?php if(isset($customer) && !empty($customer->citizenship_image)): ?>
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="customer" class="col-form-label pt-0">Citizenship Image: </label>
                                        <img src="<?php echo e(asset($customer->citizen_path)); ?>" alt="" height="100px">
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>


                    </div>


                    <hr>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).on('click', '#additemrowedu', function() {
            var b = parseFloat($("#tempedu").val());
            b = b + 1;
            $("#tempedu").val(b);
            var temp = $("#tempedu").val();
            var tst = `<div class="form-group row d-flex align-items-end appended-row-edu">

                <div class="col-sm-4">
                    <label class="control-label">Title</label>
                    <input type="text" name="title[]" class="form-control" required>
                </div>
                <div class="col-sm-3">
                    <label class="control-label">Price</label>
                    <input type="number" name="price[]" class="form-control" required>
                </div>

                <div class="col-sm-3">
                    <label class="control-label">Date</label>
                    <input type="date" name="date[]" class="form-control" required>
                </div>


                <div class="col-md-1" style="margin-top: 45px;">
                    <input class="removeitemrowedu btn btn-sm btn-danger mr-1" type="button" value="Remove row">
                </div>

            </div>`
            $('#additernary_edu').append(tst);
            selectRefresh();
        });

        $(document).on('click', '.removeitemrowedu', function() {
            $(this).closest('.appended-row-edu').remove();
        })

        function remove_product(o) {
            var p = o.parentNode.parentNode;
            p.parentNode.removeChild(p);
        }

        function remove_productforedit(o) {
            var p = o.parentNode.parentNode;
            p.parentNode.removeChild(p);
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\customermanagement\resources\views/customer/show.blade.php ENDPATH**/ ?>