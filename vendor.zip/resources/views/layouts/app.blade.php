@include('layouts.admin.head')


    <body data-topbar="dark">

        <!-- Begin page -->
        <div id="layout-wrapper">
                    <div class="container-fluid">
                        @yield('content')
                    </div>

        </div>
