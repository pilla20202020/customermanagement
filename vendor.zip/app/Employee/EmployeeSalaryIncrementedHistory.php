<?php

namespace App\Employee;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class EmployeeSalaryIncrementedHistory extends Model
{
    use HasFactory;
}
